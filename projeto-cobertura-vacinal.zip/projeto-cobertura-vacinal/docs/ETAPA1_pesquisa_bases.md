# Etapa 1 — Pesquisa e validação das bases

## Bases avaliadas

### Base 1 (escolhida) — TABNET DATASUS: "Imunizações – Cobertura – Brasil"
- Órgão responsável: Ministério da Saúde / DATASUS, dados do SI-PNI, geridos pela CGPNI
- Link: http://tabnet.datasus.gov.br/cgi/webtabx.exe?bd_pni/cpnibr.def
- Documentação técnica: http://tabnet.datasus.gov.br/cgi/pni/cpnidescr.htm
- Formato: tabulação interativa com exportação para CSV
- Período: 1994–2022 (dados após 2022 migraram para a RNDS e ficam fragmentados neste cubo)
- Nível geográfico: Brasil, regiões, UF, capitais e municípios
- Colunas: ano, imunobiológico, dose, local, cobertura (%) já calculada
- Limitações: 1994–1996 com UFs ausentes (documentado pela própria fonte); dados agregados, não microdados individuais

### Base 2 — OpenDataSUS: "Doses Aplicadas pelo PNI"
- Órgão responsável: DPNI/Ministério da Saúde
- Link: https://dadosabertos.saude.gov.br/dataset/doses-aplicadas-pelo-programa-de-nacional-de-imunizacoes-pni-2021
- Formato: CSV mensal (microdados individuais anonimizados), ~60 variáveis, API disponível
- Período: a partir de 2021, atualização semanal
- Limitações: arquivos muito grandes; não traz cobertura (%) pronta, exigiria cruzar com população-alvo

### Base 3 — Campanha Nacional de Vacinação contra Covid-19 (OpenDataSUS)
- Link: https://opendatasus.saude.gov.br/dataset/covid-19-vacinacao
- Cobre apenas Covid-19 — fora do escopo do calendário nacional completo

### Base 4 — IDB/DATASUS "Cobertura Vacinal no Primeiro Ano de Vida"
- Link: http://tabnet.datasus.gov.br/cgi/idb2000/fqf13.htm
- Série desatualizada, sem manutenção recente — não recomendada como base principal

## Decisão

**Base escolhida: Base 1 (TABNET "Imunizações – Cobertura – Brasil")**, por já
entregar a cobertura vacinal em percentual pronta, com série histórica longa,
recorte por UF/região/vacina/ano e exportação direta em CSV.

Data de validação das fontes: 18/09/2026.
