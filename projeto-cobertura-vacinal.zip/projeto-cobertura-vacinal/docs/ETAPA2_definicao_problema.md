# Etapa 2 — Definição do problema

## Contextualização
O Programa Nacional de Imunizações (PNI), criado em 1973, é um dos maiores
programas públicos de vacinação do mundo, oferecendo gratuitamente pelo SUS o
calendário nacional de vacinas. Nos últimos anos, boletins e estudos vêm
registrando queda na cobertura vacinal em vários estados, o que motiva o
acompanhamento sistemático desse indicador.

## Objetivo geral
Analisar a evolução da cobertura vacinal no Brasil entre os principais
imunobiológicos do calendário nacional, identificando padrões temporais e
diferenças regionais, com base nos dados oficiais do SI-PNI/DATASUS.

## Objetivos específicos
- Extrair e tratar os dados de cobertura vacinal por UF, vacina e ano do TABNET
- Estruturar os dados em um banco relacional (SQL) para consultas analíticas
- Calcular indicadores agregados (cobertura média, variação ano a ano, diferença regional)
- Construir visualizações exploratórias em Python
- Consolidar os resultados em um dashboard interativo no Power BI
- Documentar fontes, metodologia e limitações

## Pergunta central
Como a cobertura vacinal no Brasil evoluiu entre 1994 e 2022, e quais
diferenças podem ser observadas entre as regiões e estados brasileiros?

## Perguntas secundárias
1. Como a cobertura vacinal variou ao longo dos anos para as principais
   vacinas do calendário infantil (BCG, Tríplice Viral, Pentavalente/DTP,
   Poliomielite)?
2. Existem diferenças de cobertura entre as cinco regiões brasileiras?
3. Quais estados apresentam consistentemente os maiores e menores valores de
   cobertura no período?
4. Em que anos ocorreram quedas relevantes de cobertura, e isso se repete em
   várias vacinas ao mesmo tempo ou é específico de algumas?
5. Qual o percentual de estados/anos que atingem a meta de 95% recomendada
   pelo PNI para imunidade coletiva, por vacina?

## Escopo e limitações
- Análise descritiva e exploratória, não causal
- Período coberto: 1994–2022
- 1994–1996 têm UFs ausentes (documentado pela própria fonte)
- Valores de cobertura acima de 100% podem ocorrer (população-alvo estimada
  vs. doses reais aplicadas) — mantidos como estão, discutidos como
  limitação, nunca "corrigidos" artificialmente
- Nível geográfico: Brasil, região, UF e capitais — sem dado municipal
  completo nesta base
