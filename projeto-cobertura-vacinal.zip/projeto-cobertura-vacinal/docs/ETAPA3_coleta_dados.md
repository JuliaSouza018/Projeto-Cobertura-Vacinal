# Etapa 3 — Coleta dos dados reais (TABNET DATASUS)

## Por que este passo é manual

O TABNET (`tabnet.datasus.gov.br`) não expõe um link direto de download: ele é um
formulário HTML que gera a tabulação sob demanda, a partir das opções de Linha,
Coluna, Conteúdo e Período escolhidas pelo usuário. Por isso este passo precisa ser
feito uma vez, manualmente, por quem tem acesso ao navegador — depois disso, todo o
resto do pipeline (Python, SQL, Power BI) é automático.

## Fonte

- **Base:** Imunizações – Cobertura – Brasil (SI-PNI/CGPNI)
- **Link:** https://tabnet.datasus.gov.br/cgi/dhdat.exe?bd_pni/cpnibr.def 
- **Documentação técnica:** http://tabnet.datasus.gov.br/cgi/pni/cpnidescr.htm
- **Órgão responsável:** Ministério da Saúde / DATASUS / CGPNI

## Passo a passo

1. Acesse o link acima no navegador.
2. Em **Linha**, selecione **UF** (ou "Região" se preferir uma primeira visão macro).
3. Em **Coluna**, selecione **Ano**.
4. Em **Conteúdo**, selecione **Cobertura**.
5. Em **Período disponível**, marque os anos que quiser incluir (recomendo 2010–2022,
   já que 1994–2009 têm lacunas de UF documentadas na própria fonte).
6. Em **Seleções disponíveis**, filtre o **Imunobiológico** desejado (ex.: comece só
   com "Tríplice Viral D1" para validar o pipeline, depois repita para cada vacina do
   escopo: BCG, Pentavalente/DTP, Poliomielite, Tríplice Viral D1 e D2, Hepatite B).
7. Clique em **Mostra**.
8. Na tabela gerada, clique no link **"Copia como .CSV"** (abaixo da tabela).
9. Salve o arquivo em `data/raw/` com um nome claro, por exemplo:
   `cobertura_triplice_viral_d1_uf_2015_2022.csv`
10. Repita para cada vacina do escopo. Cada exportação vira um arquivo separado em
    `data/raw/` — o script `python/02_tratamento.py` foi escrito para ler todos os
    arquivos dessa pasta e consolidá-los automaticamente.

## Formato esperado do arquivo (documentado pelo próprio DATASUS)

- Delimitador de campo: `;`
- Separador decimal: `,`
- Primeira linha: cabeçalho com os anos (colunas)
- Primeira coluna: UF
- Linhas finais costumam trazer "Total" e notas de rodapé — o script de tratamento
  remove essas linhas automaticamente.

## Checklist antes de seguir para a Etapa 4

- [ ] Pelo menos 3 arquivos CSV reais exportados do TABNET estão em `data/raw/`
- [ ] Os arquivos abrem corretamente no Excel/LibreOffice sem erro de codificação
- [ ] Você registrou a data do seu acesso (para citar no README final)

Assim que os arquivos reais estiverem em `data/raw/`, rode:

```bash
python python/02_tratamento.py
```

---

## Registro da coleta efetivamente realizada

**Arquivos em `data/raw/`:** 16 CSVs reais exportados do TABNET, cobrindo
2 imunobiológicos × 8 anos:

| Imunobiológico | Anos | Arquivos |
|---|---|---|
| Febre Amarela | 2015–2022 | `cobertura_febreAmarela_uf_<ano>.csv` |
| Tríplice Viral D1 | 2015–2022 | `cobertura_triplice_viral_d1_uf_<ano>.csv` |

**Layout real recebido** (difere do previsto acima, ver observação):

- Codificação: **ISO-8859-1 (latin-1)**, quebra de linha CRLF
- Delimitador `;` e separador decimal `,` — como documentado
- **Sem linhas de título antes do cabeçalho e sem notas de rodapé.** A linha 1
  já é o cabeçalho da tabela.
- Cabeçalho: `"Unidade da Federação";"<Nome da vacina>"` — ou seja, a coluna de
  valores traz o **nome da vacina**, não o ano
- 27 linhas de UF no formato `"<código IBGE> <Nome da UF>"` (ex. `35 São Paulo`)
- Última linha: `"Total"` com a cobertura nacional
- Aspas nos campos são opcionais e variam entre arquivos (o
  `cobertura_triplice_viral_d1_uf_2015.csv` veio sem aspas) — o leitor de CSV
  trata os dois casos
- Nenhuma célula vazia, `-` ou `...` nesta coleta

**Observação sobre a diferença de layout:** o passo a passo acima assume
`Coluna = Ano`, o que produz UM arquivo com várias colunas de ano. A coleta
real foi feita com um arquivo por ano, com coluna única. Os dois layouts são
válidos e o `python/02_tratamento.py` agora detecta qual é qual automaticamente
(regra 6 do script) — não é necessário reexportar nada.

**Data do acesso ao TABNET:** 18/09/2026

**Cobertura do checklist:** 2 imunobiológicos, abaixo dos 3 previstos no escopo.
Para fechar o escopo original, repetir o passo a passo para BCG, Pentavalente,
Poliomielite, Tríplice Viral D2 ou Hepatite B e soltar os arquivos em
`data/raw/` — o pipeline os incorpora sem nenhuma alteração de código.
