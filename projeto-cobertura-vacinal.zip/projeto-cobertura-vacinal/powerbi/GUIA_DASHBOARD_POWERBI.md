# Etapa 7 – Guia do dashboard no Power BI

Este guia descreve como montar o dashboard a partir da base tratada
(`data/tratado/cobertura_vacinal_tratado.csv`) ou diretamente do banco
PostgreSQL carregado na Etapa 5.

## 1. Conectar os dados

**Opção A — a partir do CSV tratado (mais simples):**
1. Power BI Desktop → **Obter Dados → Texto/CSV**.
2. Selecione `data/tratado/cobertura_vacinal_tratado.csv`.
3. Confirme os tipos de coluna (`ano` como número inteiro, `cobertura_pct`
   como número decimal) e clique em **Carregar**.

**Opção B — a partir do PostgreSQL (schema estrela da Etapa 5):**
1. Power BI Desktop → **Obter Dados → Banco de Dados → PostgreSQL**.
2. Informe host/porta/banco e importe `dim_uf`, `dim_imunobiologico` e
   `fato_cobertura`.
3. Em **Gerenciar Relacionamentos**, confirme os relacionamentos
   `fato_cobertura[uf] → dim_uf[uf]` e
   `fato_cobertura[imunobiologico] → dim_imunobiologico[imunobiologico]`.

## 2. Medidas DAX sugeridas

```DAX
Cobertura Média =
AVERAGE(fato_cobertura[cobertura_pct])

% Acima da Meta PNI (95%) =
DIVIDE(
    CALCULATE(COUNTROWS(fato_cobertura), fato_cobertura[cobertura_pct] >= 95),
    CALCULATE(COUNTROWS(fato_cobertura), NOT ISBLANK(fato_cobertura[cobertura_pct]))
)

% Registros Ausentes =
DIVIDE(
    CALCULATE(COUNTROWS(fato_cobertura), ISBLANK(fato_cobertura[cobertura_pct])),
    COUNTROWS(fato_cobertura)
)

Variação vs Ano Anterior =
VAR AnoAtual = SELECTEDVALUE(fato_cobertura[ano])
VAR MediaAtual = [Cobertura Média]
VAR MediaAnterior =
    CALCULATE(
        [Cobertura Média],
        FILTER(ALL(fato_cobertura[ano]), fato_cobertura[ano] = AnoAtual - 1)
    )
RETURN
    MediaAtual - MediaAnterior
```

## 3. Visuais recomendados

- **Gráfico de linhas**: `Cobertura Média` por `ano`, quebrado por
  `imunobiologico`, com uma linha de referência fixa em 95 (meta do PNI).
- **Mapa/gráfico de barras por região**: `Cobertura Média` por `regiao`
  (vindo de `dim_uf`), quebrado por `imunobiologico`.
- **Tabela ranking de UFs**: `uf`, `Cobertura Média`, ordenada de forma
  decrescente, para reproduzir o top/bottom 5 já calculado em Python e SQL.
- **Cartão**: `% Acima da Meta PNI (95%)` e `% Registros Ausentes` como
  indicadores de transparência sobre a qualidade dos dados.
- **Segmentações (slicers)**: `ano`, `imunobiologico` e `regiao`.

Uma captura do resultado final está em `powerbi/TelaPoweBI.png`.

## 4. Publicação (opcional)

Se for publicar no Power BI Service, lembre de revisar as configurações de
privacidade/atualização de dados antes de compartilhar publicamente — a base
usada aqui é agregada (sem dados individuais), mas ainda assim vale checar.
