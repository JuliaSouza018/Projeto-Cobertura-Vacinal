"""
Etapa 3 - Inspeção da amostra real dos dados.

Só abre os CSVs exportados do TABNET (data/raw/) e mostra as primeiras
linhas, colunas e tamanho de cada um. Não trata nada ainda - é só pra eu
conferir visualmente que o que baixei está certo antes de mexer nos dados.

Uso:
    python 01_inspecao_amostra.py
"""

import pandas as pd
from pathlib import Path

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"


def listar_arquivos_raw():
    arquivos = sorted(RAW_DIR.glob("*.csv"))
    if not arquivos:
        print(
            f"Nenhum arquivo .csv encontrado em {RAW_DIR}.\n"
            "Siga docs/ETAPA3_coleta_dados.md para exportar os dados reais do "
            "TABNET antes de rodar este script."
        )
    return arquivos


def inspecionar(arquivo: Path):
    print("=" * 80)
    print(f"Arquivo: {arquivo.name}")
    try:
        # o "Copia como .CSV" do TABNET já vem direto no cabeçalho, sem
        # linhas de título antes. Leio tudo como está, inclusive a linha
        # "Total" (essa só é removida depois, no 02_tratamento.py)
        df = pd.read_csv(
            arquivo,
            sep=";",
            decimal=",",
            encoding="latin-1",
            engine="python",
        )
    except Exception as e:
        print(f"  Não foi possível ler automaticamente: {e}")
        print("  Abra o arquivo manualmente e confira o número de linhas de cabeçalho "
              "(ajuste skiprows/skipfooter neste script se necessário).")
        return

    print(f"  Linhas: {len(df)} | Colunas: {len(df.columns)}")
    print("  Colunas:", list(df.columns))
    print("  Primeiras linhas:")
    print(df.head(5).to_string(index=False))


if __name__ == "__main__":
    for arq in listar_arquivos_raw():
        inspecionar(arq)
