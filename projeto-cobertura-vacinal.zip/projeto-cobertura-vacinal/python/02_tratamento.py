"""
Etapa 4 - Tratamento dos dados com Python.

Lê os CSVs do TABNET em data/raw/, transforma de wide pra long e exporta
tudo junto em data/tratado/cobertura_vacinal_tratado.csv, pronto pra
carregar no banco (Etapa 5).

Decisões de limpeza:
1. O nome da vacina vem do cabeçalho da coluna de valores quando dá (é o
   rótulo oficial do TABNET); só uso o nome do arquivo como fallback.
2. Linhas "Total" e "Ignorado" são removidas - não são UF de verdade.
3. Cobertura vem com vírgula decimal (padrão BR) -> converto pra float.
4. Vazio ou "-" vira NaN, não 0 (0% de cobertura é outra informação).
5. Cobertura acima de 100% eu deixo como está (não "corrijo" pra 100) -
   é imprecisão da população-alvo estimada, viro limitação na análise.
6. O TABNET exporta em dois layouts dependendo do que escolhe em "Coluna",
   e o script detecta os dois sozinho:
      (a) Coluna = Ano -> um arquivo cobre vários anos, ano vem do cabeçalho
      (b) Coluna = "não ativa" -> um arquivo por ano, ano vem do nome do
          arquivo (ex. cobertura_febreAmarela_uf_2022.csv)
7. Não pulo linha nenhuma por posição (título/rodapé) - só descarto o que
   não é UF válida (regra 2), senão corro o risco de apagar UF real.
8. Se a mesma UF/ano/vacina aparecer duas vezes, o script avisa antes de
   deduplicar em vez de simplesmente escolher uma.
"""

import re
import unicodedata
import pandas as pd
from pathlib import Path

RAW_DIR = Path(__file__).resolve().parent.parent / "data" / "raw"
OUT_DIR = Path(__file__).resolve().parent.parent / "data" / "tratado"
OUT_DIR.mkdir(parents=True, exist_ok=True)

UFS_VALIDAS = {
    "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS",
    "MG", "PA", "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC",
    "SP", "SE", "TO",
}

# o TABNET exporta nome completo da UF (às vezes com código IBGE na frente,
# tipo "35 São Paulo"), não sigla. Esse mapa converte nome -> sigla.
NOME_PARA_SIGLA = {
    "ACRE": "AC", "ALAGOAS": "AL", "AMAPA": "AP", "AMAZONAS": "AM",
    "BAHIA": "BA", "CEARA": "CE", "DISTRITO FEDERAL": "DF",
    "ESPIRITO SANTO": "ES", "GOIAS": "GO", "MARANHAO": "MA",
    "MATO GROSSO": "MT", "MATO GROSSO DO SUL": "MS", "MINAS GERAIS": "MG",
    "PARA": "PA", "PARAIBA": "PB", "PARANA": "PR", "PERNAMBUCO": "PE",
    "PIAUI": "PI", "RIO DE JANEIRO": "RJ", "RIO GRANDE DO NORTE": "RN",
    "RIO GRANDE DO SUL": "RS", "RONDONIA": "RO", "RORAIMA": "RR",
    "SANTA CATARINA": "SC", "SAO PAULO": "SP", "SERGIPE": "SE",
    "TOCANTINS": "TO",
}


def _remover_acentos(texto: str) -> str:
    nfkd = unicodedata.normalize("NFKD", str(texto))
    return "".join(c for c in nfkd if not unicodedata.combining(c))


def normalizar_uf(valor: str) -> str:
    """Aceita sigla ('SP'), nome completo ('São Paulo') ou 'código nome'
    ('35 São Paulo', como o TABNET exporta) e devolve a sigla."""
    v = _remover_acentos(valor).strip().upper()
    v = re.sub(r"^\d+\s+", "", v)  # remove código do IBGE na frente, se houver
    if v in UFS_VALIDAS:
        return v
    return NOME_PARA_SIGLA.get(v, v)


def _para_snake(texto: str) -> str:
    """'Tríplice Viral  D1' -> 'triplice_viral_d1'"""
    t = _remover_acentos(texto).strip().lower()
    t = re.sub(r"[^a-z0-9]+", "_", t)
    return t.strip("_")


def nome_imuno_do_arquivo(arquivo: Path) -> str:
    """Fallback: extrai a vacina do nome do arquivo, aceitando tanto
    'cobertura_<vacina>_uf_2022' quanto 'cobertura_<vacina>_uf_2010_2022'."""
    m = re.match(r"cobertura_(.+?)_uf_\d{4}", arquivo.stem)
    return _para_snake(m.group(1)) if m else _para_snake(arquivo.stem)


def ano_do_arquivo(arquivo: Path):
    """Ano de referência quando o arquivo cobre um único ano. Retorna None se
    o nome trouxer um intervalo (ex. _2010_2022), caso em que o ano tem que
    vir das colunas."""
    m = re.search(r"_(\d{4})(_(\d{4}))?$", arquivo.stem)
    if not m or m.group(3):
        return None
    return int(m.group(1))


def _e_ano(rotulo: str) -> bool:
    return bool(re.fullmatch(r"\d{4}", str(rotulo).strip()))


def ler_arquivo_tabnet(arquivo: Path) -> pd.DataFrame:
    """Lê o CSV cru do TABNET sem descartar nenhuma linha por posição."""
    df = pd.read_csv(
        arquivo,
        sep=";",
        encoding="latin-1",
        dtype=str,          # conversão numérica é feita depois, com controle
        keep_default_na=False,
        engine="python",
    )
    df = df.rename(columns={df.columns[0]: "uf"})
    return df


def tratar_arquivo(arquivo: Path) -> pd.DataFrame:
    df = ler_arquivo_tabnet(arquivo)
    colunas_valor = [c for c in df.columns if c != "uf"]
    if not colunas_valor:
        raise ValueError("arquivo sem coluna de valores")

    # detecta o layout pelo cabeçalho (regra 6)
    if all(_e_ano(c) for c in colunas_valor):
        # (a) uma coluna por ano; a vacina vem do nome do arquivo
        df_long = df.melt(id_vars="uf", var_name="ano", value_name="cobertura_pct")
        df_long["ano"] = pd.to_numeric(df_long["ano"], errors="coerce").astype("Int64")
        imuno = nome_imuno_do_arquivo(arquivo)
    elif len(colunas_valor) == 1:
        # (b) um arquivo por ano; a vacina vem do cabeçalho da coluna (regra 1)
        ano = ano_do_arquivo(arquivo)
        if ano is None:
            raise ValueError(
                "arquivo de coluna única sem ano identificável no nome; "
                "renomeie para o padrão cobertura_<vacina>_uf_<ano>.csv"
            )
        df_long = df.rename(columns={colunas_valor[0]: "cobertura_pct"}).copy()
        df_long["ano"] = pd.Series([ano] * len(df_long), dtype="Int64")
        imuno = _para_snake(colunas_valor[0]) or nome_imuno_do_arquivo(arquivo)
    else:
        raise ValueError(
            f"layout não reconhecido; colunas de valor: {colunas_valor}"
        )

    # Regra 2: normalizar UF e descartar por conteúdo o que não é UF real
    # ("Total", "Ignorado", linhas de nota de rodapé)
    df_long["uf"] = df_long["uf"].map(normalizar_uf)
    descartadas = sorted(set(df_long.loc[~df_long["uf"].isin(UFS_VALIDAS), "uf"]))
    df_long = df_long[df_long["uf"].isin(UFS_VALIDAS)]

    faltando = UFS_VALIDAS - set(df_long["uf"])
    if faltando:
        print(f"  Atenção: UFs ausentes neste arquivo: {sorted(faltando)}")
    if descartadas:
        print(f"  Linhas não-UF descartadas: {descartadas}")

    # Regras 3 e 4: vírgula decimal -> float; "-" / vazio -> NaN
    df_long["cobertura_pct"] = (
        df_long["cobertura_pct"].astype(str).str.strip()
        .str.replace(".", "", regex=False)   # separador de milhar do TABNET
        .str.replace(",", ".", regex=False)
        .replace({"-": None, "": None, "...": None})
    )
    df_long["cobertura_pct"] = pd.to_numeric(df_long["cobertura_pct"], errors="coerce")

    df_long["imunobiologico"] = imuno
    return df_long[["uf", "ano", "imunobiologico", "cobertura_pct"]]


def main():
    arquivos = sorted(RAW_DIR.glob("*.csv"))
    if not arquivos:
        print(
            f"Nenhum arquivo .csv em {RAW_DIR}. Siga docs/ETAPA3_coleta_dados.md "
            "antes de rodar este script."
        )
        return

    partes, falhas = [], []
    for arq in arquivos:
        print(f"Tratando {arq.name} ...")
        try:
            partes.append(tratar_arquivo(arq))
        except Exception as e:
            print(f"  FALHOU: {e}")
            falhas.append(arq.name)

    if not partes:
        print("Nenhum arquivo foi tratado com sucesso.")
        return

    base = pd.concat(partes, ignore_index=True)

    # Regra 8: avisar antes de deduplicar
    chave = ["uf", "ano", "imunobiologico"]
    dups = base.duplicated(subset=chave, keep=False)
    if dups.any():
        print(f"\nAtenção: {int(dups.sum())} linhas com UF/ano/vacina repetidos "
              "(arquivos sobrepostos?). Mantendo a primeira ocorrência:")
        print(base[dups].sort_values(chave).to_string(index=False))
    base = base.drop_duplicates(subset=chave).sort_values(
        ["imunobiologico", "ano", "uf"]
    )

    pct_ausente = base["cobertura_pct"].isna().mean() * 100
    print(f"\nArquivos lidos com sucesso: {len(partes)} de {len(arquivos)}")
    if falhas:
        print(f"Arquivos com falha: {falhas}")
    print(f"Linhas finais: {len(base)}")
    print(f"Imunobiológicos: {sorted(base['imunobiologico'].unique())}")
    print(f"Anos: {int(base['ano'].min())}-{int(base['ano'].max())}")
    print(f"UFs distintas: {base['uf'].nunique()}")
    print(f"Percentual de registros com cobertura ausente: {pct_ausente:.1f}%")

    esperado = base["imunobiologico"].nunique() * base["ano"].nunique() * 27
    if len(base) != esperado:
        print(f"Atenção: esperadas {esperado} linhas para uma grade completa "
              f"(vacinas x anos x 27 UFs); a base tem {len(base)}.")

    saida = OUT_DIR / "cobertura_vacinal_tratado.csv"
    base.to_csv(saida, index=False, encoding="utf-8")
    print(f"Base tratada exportada para: {saida}")


if __name__ == "__main__":
    main()
