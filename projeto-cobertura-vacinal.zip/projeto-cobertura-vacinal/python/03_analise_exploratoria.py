"""
Etapa 6 - Análise exploratória.

Lê data/tratado/cobertura_vacinal_tratado.csv e gera:
- gráfico de evolução temporal da cobertura média nacional, por vacina
- gráfico de comparação entre regiões
- ranking de estados (maior/menor cobertura média no período)
- resumo exportado em data/tratado/resumo_indicadores.csv
"""

import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
TRATADO = BASE_DIR / "data" / "tratado" / "cobertura_vacinal_tratado.csv"
OUT_DIR = BASE_DIR / "data" / "tratado"
FIG_DIR = BASE_DIR / "docs" / "figuras"
FIG_DIR.mkdir(parents=True, exist_ok=True)

# UF -> Região (divisão oficial do IBGE, não precisa de fonte externa)
REGIAO = {
    "AC": "Norte", "AP": "Norte", "AM": "Norte", "PA": "Norte", "RO": "Norte",
    "RR": "Norte", "TO": "Norte",
    "AL": "Nordeste", "BA": "Nordeste", "CE": "Nordeste", "MA": "Nordeste",
    "PB": "Nordeste", "PE": "Nordeste", "PI": "Nordeste", "RN": "Nordeste",
    "SE": "Nordeste",
    "DF": "Centro-Oeste", "GO": "Centro-Oeste", "MT": "Centro-Oeste",
    "MS": "Centro-Oeste",
    "ES": "Sudeste", "MG": "Sudeste", "RJ": "Sudeste", "SP": "Sudeste",
    "PR": "Sul", "RS": "Sul", "SC": "Sul",
}


def carregar_base() -> pd.DataFrame:
    if not TRATADO.exists():
        raise SystemExit(
            f"{TRATADO} não existe ainda. Rode 02_tratamento.py primeiro "
            "(e antes dele, siga docs/ETAPA3_coleta_dados.md)."
        )
    df = pd.read_csv(TRATADO)
    df["regiao"] = df["uf"].map(REGIAO)
    return df


def evolucao_temporal(df: pd.DataFrame):
    media_ano = df.groupby(["imunobiologico", "ano"])["cobertura_pct"].mean().reset_index()
    fig, ax = plt.subplots(figsize=(9, 5))
    for imuno, grupo in media_ano.groupby("imunobiologico"):
        ax.plot(grupo["ano"], grupo["cobertura_pct"], marker="o", label=imuno)
    ax.axhline(95, color="red", linestyle="--", linewidth=1, label="Meta PNI (95%)")
    ax.set_title("Cobertura vacinal média nacional por ano")
    ax.set_xlabel("Ano")
    ax.set_ylabel("Cobertura (%)")
    ax.legend()
    fig.tight_layout()
    caminho = FIG_DIR / "evolucao_temporal.png"
    fig.savefig(caminho, dpi=150)
    print(f"Gráfico salvo em {caminho}")


def comparacao_regional(df: pd.DataFrame):
    media_regiao = df.groupby(["regiao", "imunobiologico"])["cobertura_pct"].mean().reset_index()
    pivot = media_regiao.pivot(index="regiao", columns="imunobiologico", values="cobertura_pct")
    fig, ax = plt.subplots(figsize=(9, 5))
    pivot.plot(kind="bar", ax=ax)
    ax.set_title("Cobertura vacinal média por região (todo o período)")
    ax.set_ylabel("Cobertura (%)")
    fig.tight_layout()
    caminho = FIG_DIR / "comparacao_regional.png"
    fig.savefig(caminho, dpi=150)
    print(f"Gráfico salvo em {caminho}")


def ranking_estados(df: pd.DataFrame) -> pd.DataFrame:
    resumo = (
        df.groupby("uf")["cobertura_pct"]
        .agg(cobertura_media="mean", cobertura_minima="min", cobertura_maxima="max")
        .reset_index()
        .sort_values("cobertura_media", ascending=False)
    )
    return resumo


def main():
    df = carregar_base()
    evolucao_temporal(df)
    comparacao_regional(df)
    resumo = ranking_estados(df)

    saida = OUT_DIR / "resumo_indicadores.csv"
    resumo.to_csv(saida, index=False)
    print(f"Resumo por estado exportado para {saida}")

    print("\nTop 5 estados por cobertura média no período:")
    print(resumo.head(5).to_string(index=False))
    print("\nBottom 5 estados por cobertura média no período:")
    print(resumo.tail(5).to_string(index=False))


if __name__ == "__main__":
    main()
