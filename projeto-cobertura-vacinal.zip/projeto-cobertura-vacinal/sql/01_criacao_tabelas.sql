-- Etapa 5 - Banco de dados SQL (PostgreSQL)
--
-- Esquema estrela simples: dim_uf e dim_imunobiologico são as dimensões,
-- fato_cobertura guarda a cobertura por uf/ano/vacina. Separar assim evita
-- repetir texto (nome de UF, nome de vacina) e facilita os JOINs no Power BI.

CREATE TABLE IF NOT EXISTS dim_uf (
    uf              CHAR(2) PRIMARY KEY,
    nome_uf         VARCHAR(40) NOT NULL,
    regiao          VARCHAR(20) NOT NULL
);

CREATE TABLE IF NOT EXISTS dim_imunobiologico (
    imunobiologico  VARCHAR(60) PRIMARY KEY,
    descricao       VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS fato_cobertura (
    id              SERIAL PRIMARY KEY,
    uf              CHAR(2) NOT NULL REFERENCES dim_uf(uf),
    ano             SMALLINT NOT NULL,
    imunobiologico  VARCHAR(60) NOT NULL REFERENCES dim_imunobiologico(imunobiologico),
    cobertura_pct   NUMERIC(6,2),  -- NULL = dado ausente na fonte, nunca 0 artificial
    UNIQUE (uf, ano, imunobiologico)
);

CREATE INDEX IF NOT EXISTS idx_fato_cobertura_ano ON fato_cobertura(ano);
CREATE INDEX IF NOT EXISTS idx_fato_cobertura_imuno ON fato_cobertura(imunobiologico);
