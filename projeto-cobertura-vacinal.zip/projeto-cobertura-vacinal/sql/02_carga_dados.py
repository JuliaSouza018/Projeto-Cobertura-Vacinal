"""
Etapa 5 - Carga dos dados tratados no PostgreSQL.

Lê data/tratado/cobertura_vacinal_tratado.csv (dados reais já limpos pela
Etapa 4) e carrega em dim_uf, dim_imunobiologico e fato_cobertura.

Pré-requisitos:
    pip install psycopg2-binary pandas
    - Um banco PostgreSQL criado, com sql/01_criacao_tabelas.sql já executado
      (ex.: psql -d cobertura_vacinal -f sql/01_criacao_tabelas.sql)

Configuração:
    As credenciais NÃO ficam no código. Copie .env.example para .env na raiz
    do projeto, ajuste os valores e este script lê tudo de lá (ou das
    variáveis de ambiente do sistema, se você preferir defini-las assim).

Uso:
    python sql/02_carga_dados.py
"""

import os
import pandas as pd
import psycopg2
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
TRATADO = BASE_DIR / "data" / "tratado" / "cobertura_vacinal_tratado.csv"


def _carregar_dotenv(caminho: Path):
    """Lê um .env simples (CHAVE=VALOR) pro os.environ, sem lib externa.
    Não sobrescreve variável que já esteja definida no ambiente."""
    if not caminho.exists():
        return
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, valor = linha.split("=", 1)
        os.environ.setdefault(chave.strip(), valor.strip())


_carregar_dotenv(BASE_DIR / ".env")

CONEXAO = (
    f"dbname={os.environ.get('DB_NAME', 'cobertura_vacinal')} "
    f"user={os.environ.get('DB_USER', 'postgres')} "
    f"password={os.environ.get('DB_PASSWORD', '')} "
    f"host={os.environ.get('DB_HOST', 'localhost')} "
    f"port={os.environ.get('DB_PORT', '5432')}"
)

if not os.environ.get("DB_PASSWORD"):
    raise SystemExit(
        "DB_PASSWORD não definida. Copie .env.example para .env e preencha "
        "suas credenciais locais antes de rodar este script."
    )

REGIAO = {
    "AC": "Norte", "AP": "Norte", "AM": "Norte", "PA": "Norte", "RO": "Norte",
    "RR": "Norte", "TO": "Norte",
    "AL": "Nordeste", "BA": "Nordeste", "CE": "Nordeste", "MA": "Nordeste",
    "PB": "Nordeste", "PE": "Nordeste", "PI": "Nordeste", "RN": "Nordeste",
    "SE": "Nordeste",
    "DF": "Centro-Oeste", "GO": "Centro-Oeste", "MT": "Centro-Oeste",
    "MS": "Centro-Oeste",
    "ES": "Sudeste", "MG": "Sudeste", "RJ": "Sudeste", "SP": "Sudeste",
    "PR": "Sul", "RS": "Sul", "SC": "Sul",
}

NOME_UF = {
    "AC": "Acre", "AL": "Alagoas", "AP": "Amapá", "AM": "Amazonas",
    "BA": "Bahia", "CE": "Ceará", "DF": "Distrito Federal",
    "ES": "Espírito Santo", "GO": "Goiás", "MA": "Maranhão",
    "MT": "Mato Grosso", "MS": "Mato Grosso do Sul", "MG": "Minas Gerais",
    "PA": "Pará", "PB": "Paraíba", "PR": "Paraná", "PE": "Pernambuco",
    "PI": "Piauí", "RJ": "Rio de Janeiro", "RN": "Rio Grande do Norte",
    "RS": "Rio Grande do Sul", "RO": "Rondônia", "RR": "Roraima",
    "SC": "Santa Catarina", "SP": "São Paulo", "SE": "Sergipe",
    "TO": "Tocantins",
}


def main():
    if not TRATADO.exists():
        raise SystemExit(f"{TRATADO} não existe. Rode python/02_tratamento.py primeiro.")

    df = pd.read_csv(TRATADO)

    conn = psycopg2.connect(CONEXAO)
    cur = conn.cursor()

    # dim_uf
    for uf in sorted(df["uf"].unique()):
        cur.execute(
            """INSERT INTO dim_uf (uf, nome_uf, regiao) VALUES (%s, %s, %s)
               ON CONFLICT (uf) DO NOTHING""",
            (uf, NOME_UF.get(uf, uf), REGIAO.get(uf, "Desconhecida")),
        )

    # dim_imunobiologico
    for imuno in sorted(df["imunobiologico"].unique()):
        cur.execute(
            """INSERT INTO dim_imunobiologico (imunobiologico, descricao)
               VALUES (%s, %s) ON CONFLICT (imunobiologico) DO NOTHING""",
            (imuno, imuno.replace("_", " ").title()),
        )

    # fato_cobertura
    registros = [
        (row.uf, int(row.ano), row.imunobiologico,
         None if pd.isna(row.cobertura_pct) else float(row.cobertura_pct))
        for row in df.itertuples()
    ]
    cur.executemany(
        """INSERT INTO fato_cobertura (uf, ano, imunobiologico, cobertura_pct)
           VALUES (%s, %s, %s, %s)
           ON CONFLICT (uf, ano, imunobiologico) DO UPDATE
             SET cobertura_pct = EXCLUDED.cobertura_pct""",
        registros,
    )

    conn.commit()
    print(f"Carga concluída: {len(registros)} registros em fato_cobertura.")
    cur.close()
    conn.close()


if __name__ == "__main__":
    main()
