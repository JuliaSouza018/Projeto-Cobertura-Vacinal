-- Etapa 5 - Consultas analíticas
-- Cada bloco responde a uma pergunta do projeto.

-- 1) Evolução da cobertura média nacional por vacina e ano
SELECT
    imunobiologico,
    ano,
    ROUND(AVG(cobertura_pct), 2) AS cobertura_media_nacional
FROM fato_cobertura
WHERE cobertura_pct IS NOT NULL
GROUP BY imunobiologico, ano
ORDER BY imunobiologico, ano;

-- 2) Cobertura média por região (todo o período carregado)
SELECT
    d.regiao,
    f.imunobiologico,
    ROUND(AVG(f.cobertura_pct), 2) AS cobertura_media_regional
FROM fato_cobertura f
JOIN dim_uf d ON d.uf = f.uf
WHERE f.cobertura_pct IS NOT NULL
GROUP BY d.regiao, f.imunobiologico
ORDER BY f.imunobiologico, cobertura_media_regional DESC;

-- 3) Top 5 e bottom 5 estados por cobertura média (todas as vacinas agregadas)
SELECT uf, ROUND(AVG(cobertura_pct), 2) AS cobertura_media
FROM fato_cobertura
WHERE cobertura_pct IS NOT NULL
GROUP BY uf
ORDER BY cobertura_media DESC
LIMIT 5;

SELECT uf, ROUND(AVG(cobertura_pct), 2) AS cobertura_media
FROM fato_cobertura
WHERE cobertura_pct IS NOT NULL
GROUP BY uf
ORDER BY cobertura_media ASC
LIMIT 5;

-- 4) Anos em que a cobertura média nacional caiu em relação ao ano anterior,
--    por vacina (usa LAG para comparar ano a ano)
WITH media_ano AS (
    SELECT imunobiologico, ano, AVG(cobertura_pct) AS cobertura_media
    FROM fato_cobertura
    WHERE cobertura_pct IS NOT NULL
    GROUP BY imunobiologico, ano
)
SELECT
    imunobiologico,
    ano,
    ROUND(cobertura_media, 2) AS cobertura_media,
    ROUND(cobertura_media - LAG(cobertura_media) OVER (
        PARTITION BY imunobiologico ORDER BY ano
    ), 2) AS variacao_vs_ano_anterior
FROM media_ano
ORDER BY imunobiologico, ano;

-- 5) Percentual de combinações UF/ano que atingiram a meta de 95% do PNI,
--    por vacina
SELECT
    imunobiologico,
    ROUND(
        100.0 * COUNT(*) FILTER (WHERE cobertura_pct >= 95) / COUNT(*),
        1
    ) AS pct_uf_ano_acima_meta
FROM fato_cobertura
WHERE cobertura_pct IS NOT NULL
GROUP BY imunobiologico
ORDER BY pct_uf_ano_acima_meta DESC;

-- 6) Percentual de registros ausentes por imunobiológico
SELECT
    imunobiologico,
    ROUND(100.0 * COUNT(*) FILTER (WHERE cobertura_pct IS NULL) / COUNT(*), 1)
        AS pct_registros_ausentes
FROM fato_cobertura
GROUP BY imunobiologico
ORDER BY pct_registros_ausentes DESC;
